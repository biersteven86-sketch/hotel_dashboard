/* hotel-dashboard minimal server (CommonJS) */
require("dotenv").config();
const path = require("path");
const express = require("express");
const session = require("express-session");

const app  = express();
const PORT = process.env.PORT || 3011;

app.disable("x-powered-by");
app.set("trust proxy", true);
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "hotel-dashboard-session",
  resave: false,
  saveUninitialized: false,
  cookie: { sameSite: "lax" }
}));

// Statische Dateien (ohne auto-index, damit / auf login zeigt)
app.use(express.static(path.join(__dirname, "public"), { index: false }));

// Root -> Loginseite
app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "public", "login.html")));

// GET /login.html (falls direkt aufgerufen)
app.get("/login.html", (_req, res) => res.sendFile(path.join(__dirname, "public", "login.html")));

// POST /login -> Dummy-Login, danach Redirect auf /ibelsa.html
app.post("/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.redirect("/login.html");
  req.session.user = { name: username, at: Date.now() };
  return res.redirect(303, "/ibelsa.html");
});

// einfache Zielseite
app.get("/ibelsa.html", (_req, res) => {
  res.send("<!doctype html><html><head><meta charset=utf-8><title>ibelsa</title></head><body><h1>Login OK</h1><p>Weiter gehts…</p></body></html>");
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("Hotel Dashboard läuft auf Port " + PORT);
});
