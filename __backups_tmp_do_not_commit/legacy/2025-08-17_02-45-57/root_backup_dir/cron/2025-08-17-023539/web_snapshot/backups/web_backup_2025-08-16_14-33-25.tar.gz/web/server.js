require("dotenv").config();
const express = require("express");
const path    = require("path");
const app     = express();
const PORT    = process.env.PORT || 3011;

// --- TOP-DEBUG: faengt jede POST-/login früh ab (nur Diagnose) ---
app.post("/login", (req, res) => {
  console.log("TOP_DEBUG: POST /login wurde getroffen", {method:req.method, url:req.url});
  return res.status(204).end();
});
// --- END TOP-DEBUG ---


app.disable("x-powered-by");
app.set("trust proxy", true);
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Statische Dateien aus ./public
app.use(express.static(path.join(__dirname, "public"), { index: false }));

// Root sofort auf /login weiterleiten
app.get("/", (_req, res) => res.redirect(302, "/login"));

// Login-Formular (liefert public/login.html)
app.get("/login", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

// Login-POST -> wenn OK, ibelsa.html ausliefern
app.post("/login", (req, res) => {
    console.log(">>> POST /login Handler wurde getriggert, body=", req.body);
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.redirect(302, "/login");
  }
  // direkt Datei liefern, kein Redirect
  res.sendFile(path.join(__dirname, "public", "ibelsa.html"));
});

// Fallback: unbekannte Pfade -> 404 klare Meldung
app.use((_req, res) => res.status(404).send("Not Found"));

app.listen(PORT, "127.0.0.1", () => {
  console.log("Hotel Dashboard läuft auf Port", PORT);
});

// --- DEBUG at startup: list all registered routes (method + path)
try {
  const routes = [];
  (app._router?.stack || []).forEach(s => {
    if (s.route) {
      const methods = Object.keys(s.route.methods||{}).join(',').toUpperCase();
      routes.push(`${methods} ${s.route.path}`);
    }
  });
  console.log("ROUTES_AT_STARTUP:", routes.join(" | "));
} catch (e) {
  console.log("ROUTES_AT_STARTUP_ERROR:", String(e));
}
// --- END DEBUG
